package com.kh.product.web.form;

import lombok.Data;

@Data
public class ListForm {
//  뷰에서 보여줄 내용
  private Long productId;
  private String pname;

}
